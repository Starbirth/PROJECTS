#ifndef COMMON_H
#define COMMON_H

/*Magic string to identify whether file is encoded or not*/
#define MAGIC_STRING "#*"

#endif
