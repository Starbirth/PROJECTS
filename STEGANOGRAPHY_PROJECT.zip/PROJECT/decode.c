#include<stdio.h>
#include<string.h>
#include "types.h"
#include "common.h"
#include "decode.h"
#include<stdlib.h>

/*opening files for read and write*/
Status open_files_decode(DecodeInfo *deInfo)
{
	//stego image file
	deInfo -> fptr_stego_image = fopen(deInfo -> src_fname, "r");
	
	//Error handling
	if(deInfo -> fptr_stego_image  == NULL)
	{
		perror("fopen");
		fprintf(stderr,"ERROR : Unable to open files %s\n",deInfo -> src_fname);
		return e_failure;
	}
		return e_success;
}

/*magic string check*/
Status check_magic_string(DecodeInfo *deInfo)		
{
	deInfo -> magic_string = MAGIC_STRING;
	int len = strlen(deInfo -> magic_string);
	int i;
	char check_magic_string[len+1], str[8];
	
	/*pass the headers and go to the magic string position*/
	fseek(deInfo -> fptr_stego_image, 54, SEEK_SET);
	
	for(i = 0; i < len; i++)
	{
		fread(str, 8, sizeof(char), deInfo -> fptr_stego_image);
		decode_magic_string_from_lsb(str, &check_magic_string[i]);		//function at line 50
	}
	check_magic_string[i] = '\0';
	printf("MAGIC STRING DECODED = %s\n",check_magic_string);
	for(i = 0; i < len; i++)
	{
		if(check_magic_string[i] && deInfo -> magic_string[i])
			if(check_magic_string[i] != deInfo -> magic_string[i])
				return e_failure;
	}
	return e_success;
}

/*decoding lsb of 8 bytes and forming a character*/
Status decode_magic_string_from_lsb(char *str, char *check_magic_string)
{
	char ch = 0x00;
	int j=7;
	for(int i = 0; i < 8; i++)
	{
		ch = ch | ((str[i] & 1) << j);
		j--;
	}
	*check_magic_string = ch;
	
	return e_success;
}

/*decoding sizeof extension of secret file*/
Status get_extension_size(DecodeInfo *deInfo)
{
	char str[sizeof(uint) * 8 ];
	uint size;
		
	fread(str, 8, 4, deInfo -> fptr_stego_image);
	
	int j = 31;
	for(int i = 0; i < 32; i++)
	{
		size = size | ((str[i] & 1) << j);
		j--;
	}
	deInfo -> secret_file_extn_size = size;
	//printf("size=%u\n",deInfo -> secret_file_extn_size);
	return e_success;
}

/*decoding secret file extension*/
Status get_secret_file_extension(DecodeInfo *deInfo)
{
	deInfo -> secret_file_extn = malloc(deInfo -> secret_file_extn_size+1);
	int i;
	for(i = 0; i < deInfo -> secret_file_extn_size; i++)
	{
		decode_data_from_lsb(&deInfo -> secret_file_extn[i], deInfo);	//function at line 98
	}
	deInfo -> secret_file_extn[i]='\0';
	printf("secret file extension=%s\n",deInfo -> secret_file_extn);
	return e_success;
}

/*decoding lsb of 8 bytes and forming a character*/
Status decode_data_from_lsb(char *destination, DecodeInfo *deInfo)
{
	char str[8], ch = 0x00;
	fread(str, 8, sizeof(char), deInfo -> fptr_stego_image);
	int j = 7;
	for(int i = 0; i < 8; i++)
	{
		ch = ch | ((str[i] & 1) << j--);
	}
	*destination = ch;
	return e_success;
}

/*decoding secret file size*/
Status get_secret_file_size(DecodeInfo *deInfo)
{
	char str[sizeof(uint) * 8 ];
	uint size;	
	fread(str, 8, 4, deInfo -> fptr_stego_image);
	
	int j = 31;
	for(int i = 0; i < 32; i++)
	{
		size = size | ((str[i] & 1) << j);
		j--;
	}
	deInfo -> secret_fsize = size;
	printf("Secret file size= %u bytes\n",deInfo -> secret_fsize);
	return e_success;	
}

/*creating a output for decoding secret file*/
Status create_decode_file(DecodeInfo *deInfo)
{
	char *str;
	deInfo -> decode_fname = "decode.txt";
	deInfo -> fptr_decode_file = fopen(deInfo -> decode_fname, "w");
	return e_success;
}

/*decoding the secret file*/
Status decode_from_image(DecodeInfo *deInfo)
{
	char ch;
	for(int i = 0; i< deInfo -> secret_fsize; i++)
	{
		decode_data_from_lsb(&ch, deInfo);		//function at line 98
		fputc( ch, deInfo -> fptr_decode_file);
	}
	return e_success;
}


Status do_decoding(DecodeInfo *deInfo)
{
	
	if(open_files_decode(deInfo) == e_success)		//function at line 8
	{
		printf("Open files is a success\n");
		if(check_magic_string(deInfo) == e_success)	//function at line 23
		{
			printf("Magic string matched. The file is encoded\n");
			if(get_extension_size(deInfo) == e_success)		//function at line 65
			{
				printf("Secret file Extension size is found\n");
				if(get_secret_file_extension(deInfo) == e_success)		//function at line 84
				{	
					printf("Secret file Extension is found\n");
					if(get_secret_file_size(deInfo) == e_success)		//function at line 112
					{	
						printf("Secret file size is found\n");	
						if(create_decode_file(deInfo) == e_success)	//function at line 130
						{
							printf("Output file for decoded info is created\n");
							printf("Started decoding %d bytes of information from secret file\n",deInfo -> secret_fsize);
							if(decode_from_image(deInfo) == e_success)		//function at line 139
							{
								printf("Encoded information is decoded\n");
							}
							else
							{
								printf("DECODING IS UNSUCCESSFULL\n");
								return e_failure;
							}
						}
						else
						{
							printf("Output file is not created\n");
							return e_failure;
						}
					}
					else
					{
						printf("Secret file size not found!!\n");
						return e_failure;
					}
				}
				else
				{
					printf("Secret file Extension is not found\n");
					e_failure;
				}
			}			
			else
			{
				printf("Extension file size can't be found\n");
				return e_failure;
			}	
		}
		else
		{
			printf("Magic string not found. The file is not encoded\n");
			return e_failure;
		}
	}
	else
	{
		printf("Open files is a Failure!!\n");
		return e_failure;
	}
	return e_success;
}

