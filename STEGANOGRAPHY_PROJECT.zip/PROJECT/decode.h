#ifndef DECODE_H
#define DECODE_H

#include "types.h"	//for user defined types

#define FILE_EXTENSION 4

typedef struct _DecodeInfo
{
	//image info
	FILE *fptr_stego_image;
	char *src_fname;
	char *magic_string;
	uint image_file_size;
	
	//decode info
	FILE *fptr_decode_file;
	char *decode_fname;
	uint secret_fsize;
	uint secret_file_extn_size;
	char *secret_file_extn;
} DecodeInfo;

/*read and validation of arguments passed for decoding*/
Status read_and_validate_decode_args(char **argv, DecodeInfo *deInfo);

/*function that actually doing the decoding*/
Status do_decoding(DecodeInfo *deInfo);

/*opening files for read and write*/
Status open_files_decode(DecodeInfo *deInfo);

/*checking if magic string is present*/
Status check_magic_string(DecodeInfo *deInfo);

/*decoding lsb of 8 bytes and forming a character*/
Status decode_magic_string_from_lsb(char *str, char *check_magic_string);

/*decoding sizeof extension of secret file*/
Status get_extension_size(DecodeInfo *deInfo);

/*decoding secret file extension*/
Status get_secret_file_extension(DecodeInfo *deInfo);

/*decoding lsb of 8 bytes and forming a character*/
Status decode_data_from_lsb(char *destination, DecodeInfo *deInfo);

/*creating a output for decoding secret file*/
Status create_decode_file(DecodeInfo *deInfo);

/*decoding secret file size*/
Status get_secret_file_size(DecodeInfo *deInfo);

/*decoding the secret file*/
Status decode_from_image(DecodeInfo *deInfo);



#endif

