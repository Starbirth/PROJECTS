#include <stdio.h>
#include <string.h>
#include "encode.h"
#include "decode.h"
#include "types.h"

int main(int argc, char **argv)
{	
	uint img_size;
	/*encode operation*/
	if(check_operation_type(argv) == e_encode)
	{
		printf("Selected Encoding\n");
		EncodeInfo encInfo;
		if( read_and_validate_encode_args(argv, &encInfo) == e_success )
		{
			printf("Read and Validate is Successful\n");
			if( do_encoding(&encInfo) == e_success)
			{
				printf("Completed Encoding\n");
			}
			else
			{
				printf("Failure : Encoding is not done\n");
			}
		}
		else
		{
			printf("Read and validate was not successful\n");
		}
	}
	/*decode operation*/
	else if(check_operation_type(argv) == e_decode)
	{
		printf("Selected Decoding\n");
		DecodeInfo deInfo;
		if( read_and_validate_decode_args(argv, &deInfo) == e_success )
		{
			printf("Read and validate is successful\n");
			if( do_decoding(&deInfo) == e_success )
			{
				printf("Completed Decoding\n");
			}
			else
			{
				printf("Failure : Decoding is not done\n");
			}		
		}
		else
		{
			printf("Read and validate is not successful\n");
		}
	}
	/*error for invalid operation in command line arguments*/
	else
	{
		printf("Invalid option \nUsage:\nEncoding: ./a.out -e beautiful.bmp secret.txt stego.bmp\nDecoding: ./a.out -d stego.bmp\n");
	}
	
	return 0;
}

/*encoding or decoding check*/
OperationType check_operation_type(char *argv[])
{
	if(argv[1] == NULL)
		return e_unsupported;
	if (strcmp(argv[1], "-e") == 0)
		return e_encode;
	else if(strcmp(argv[1], "-d") == 0)
		return e_decode;
	else
		return e_unsupported;
}

/*read and validation of files passed for encoding*/
Status read_and_validate_encode_args(char *argv[], EncodeInfo *encInfo)
{
	if(argv [2] == NULL || argv[3] == NULL )
	{
		printf("Invalid option \nUsage:\nEncoding: ./a.out -e beautiful.bmp secret.txt stego.bmp\n");
		return e_failure;
	}
	
	if(strstr(argv[2],".") == NULL)
	{
		printf("Invalid option \nUsage:\nEncoding: ./a.out -e beautiful.bmp secret.txt stego.bmp\n");
		return e_failure;
	}	
	if(strcmp((strstr(argv[2],".")), ".bmp") == 0)
	{
		encInfo -> src_image_fname = argv[2];
	}
	else
	{
		printf("Invalid option \nUsage:\nEncoding: ./a.out -e beautiful.bmp secret.txt stego.bmp\n");
		return e_failure;
	}
	
	if(strstr(argv[3],".") == NULL)
	{
		printf("Invalid option \nUsage:\nEncoding: ./a.out -e beautiful.bmp secret.txt stego.bmp\n");
		return e_failure;
	}	
		 
	if(strcmp((strstr(argv[3],".")), ".txt") == 0)
	{
		encInfo -> secret_fname = argv[3];
		encInfo -> secret_file_extn = ".txt";
	}
	else
	{
		printf("Invalid option \nUsage:\nEncoding: ./a.out -e beautiful.bmp secret.txt stego.bmp\n");
		return e_failure;
	}
	
	if(argv[4] != NULL)
	{
		if(strstr(argv[4],".") == NULL)
		{	
			printf("Invalid option \nUsage:\nEncoding: ./a.out -e beautiful.bmp secret.txt stego.bmp\n");
			return e_failure;
		}
		
		if(strcmp((strstr(argv[4],".")), ".bmp") == 0)
		{
			encInfo -> stego_image_fname = argv[4];
			printf("Output file will be in the given name : %s\n",argv[4]);
		}
		else
		{
			printf("ERROR : Output file given is not suitable for encoding\n");
			return e_failure;
		}
	}
	else
	{
		encInfo -> stego_image_fname = "stego.bmp";
		printf("Output file will be in the name : %s\n",encInfo -> stego_image_fname);
	}
	return e_success;
}

/*read and validation of files passed for decoding*/
Status read_and_validate_decode_args(char **argv, DecodeInfo *deInfo)
{
	if(argv[2] == NULL)
	{
		printf("\nInvalid input\nUsage:\nDecoding: ./a.out -d stego.bmp\n");
		return e_failure;
	}
	if(strstr(argv[2],".") == NULL)
	{
		printf("\nInvalid input\nUsage:\nDecoding: ./a.out -d stego.bmp\n");
		return e_failure;
	}
	
	if(strcmp ((strstr(argv[2], ".")), ".bmp") == 0)
	{
		if(argv[3] != NULL)	
		{
			printf("\nInvalid input\nUsage:\nDecoding: ./a.out -d stego.bmp\n");
			return e_failure;
		
		}
		deInfo -> src_fname = argv[2];
		return e_success;
	}
	else
	{
		printf("\nInvalid option \nUsage:\nDecoding: ./a.out -d stego.bmp\n");
		return e_failure;
	}
}
