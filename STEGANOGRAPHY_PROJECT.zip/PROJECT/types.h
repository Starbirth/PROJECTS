#ifndef TYPES_H
#define TYPES_H

/*user defined types*/
typedef unsigned int uint;

/*Status will be used in function return type*/
typedef enum
{
	e_success,
	e_failure
} Status;

/*To find the command line user choice of operation*/
typedef enum
{
	e_encode,
	e_decode,
	e_unsupported
} OperationType;

#endif
